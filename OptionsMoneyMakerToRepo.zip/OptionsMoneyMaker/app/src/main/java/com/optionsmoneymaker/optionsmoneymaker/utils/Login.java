package com.optionsmoneymaker.optionsmoneymaker.utils;

/**
 * Created by Pranshu on 12-11-2017.
 */

public class Login
    {
        //private content;

        private String message;

        private String existance;

        private String email;

        private String status;

        private String userId;

        private String levelName;


        private String firstName;

//        public Content getContent ()
//        {
//            return content;
//        }
//
//        public void setContent (Content content)
//        {
//            this.content = content;
//        }

        public String getMessage ()
        {
            return message;
        }

        public void setMessage (String message)
        {
            this.message = message;
        }

        public String getExistance ()
        {
            return existance;
        }

        public void setExistance (String existance)
        {
            this.existance = existance;
        }

        public String getEmail ()
        {
            return email;
        }

        public void setEmail (String email)
        {
            this.email = email;
        }

        public String getStatus ()
        {
            return status;
        }

        public void setStatus (String status)
        {
            this.status = status;
        }

        public String getUserId ()
        {
            return userId;
        }

        public void setUserId (String userId)
        {
            this.userId = userId;
        }

        public String getLevelName ()
        {
            return levelName;
        }

        public void setLevelName (String levelName)
        {
            this.levelName = levelName;
        }

//        public null getDevice_id ()
//    {
//        return device_id;
//    }
//
//        public void setDevice_id (null device_id)
//        {
//            this.device_id = device_id;
//        }

        public String getFirstName ()
        {
            return firstName;
        }

        public void setFirstName (String firstName)
        {
            this.firstName = firstName;
        }

//        @Override
        //public String toString()
//        {
//            return "ClassPojo [content = "+content+", message = "+message+", existance = "+existance+", email = "+email+", status = "+status+", userId = "+userId+", levelName = "+levelName+", device_id = "+device_id+", firstName = "+firstName+"]";
//        }
    }

